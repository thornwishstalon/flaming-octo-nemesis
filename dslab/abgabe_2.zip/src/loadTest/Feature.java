package loadTest;

public class Feature {
	String[] feat= new String[3];
	
	public Feature(){
		feat[0]="\n"+
"        .ux+.\n"+                   
"    z?!!!!!!!!!h\n"+                
"   !!!!!!!!!!!!!?\n"+               
"  M!!!!!!!!!!!!!!?\n"+              
"  !!!!!!!!!!!!!!!!%L\n"+            
"   X!!!X\"   `X!!H\"\"\"+\n"+           
"   '!!!>  O  '!6  o  :\n"+          
"    R!!%     X!t     '\n"+          
"    E!!!!!T!!!!!!RTR\n"+            
"    X!!!!!!!!!!!!!!?%\n"+           
"    !!X$$$$!!!!!!!t!!r\n"+          
" ' d!!!##*%!!M!!R!X!X\n"+           
".=  @t!!!!X!X#!!X!!M!X\n"+           
".=     '!!?@X!!!*U@@9\n"+               
".^         9!!!!!!t!!!@':\n"+              
":L           'XT@UUXR!!f   `\n"+             
":   \"          ?!!!!!!!F     !<\n"+           
"'          ?!!!!H       '~\n"+           
"~      ~          'XX\"        ''\n"+           
"'          >\"          ' >\n"+          
"' >     z\"             M >\n"+
"'~  :~                 > M\n"+          
"'   ?4 `              '  M\n"+          
"L  '  .              ?  `\n"+          
"'%f   ^+.           '   L\n"+         
" \".     ^\"         %  '\n"+         
"   \"x  \"+.. .z`    '   4\n"+        
":             @xxxnmm!%ms\n      :   L\n"+       
"%          d!!!!!!!!!!!!!!h   !   '>\n"+      
"%.      !!!!!!!!!?@X!!!!!?: '    `\n"+      
"^%.  <N!!!!!!!!!!!@\"*XU!! '    .~\n"+     
"4 X\"+.H!!!!!!!!!!!?x   ^~!  uM!X\n"+     
"'\"~~\"\"   <\">4!!!!!!!!!!!!!T   '!!!!!!?\n"; 

		feat[1]="\n"+
"                 o\n"+
"                 |\n"+
"                '~'.\n"+
"               /     \"\n"+
"              |   ____|_\n"+
"              |  '___,,_'         .-------------------------.\n"+
"              |  ||(o |o)|       ( BITE MY SHINY METAL CODE! )\n"+
"              |   -------         ,-------------------------'\n"+
"              |  _____|         -'\n"+
"              \\  '####,\n"+
"               -------\n" +
"             /________\\\n"+
"           (  )        |)\n"+
"           '_ ' ,------|\\         __\n"+
"          /_ /  |      |_\\        ||\n"+
"         /_ /|  |     o| _\\      _||_\n"+ 
"        /_ / |  |      |\\ _\\_____|  |\n"+
"       (  (  |  |      | (_,_,_,_|  |\n"+
"        \\ _\\ |   ------|         |__|\n"+        
"         \\ _\\|_________|\n"+
"          \\ _\\ \\__\\\\__\\\n"+
"          |__| |__||__|\n"+
"       ||/__/  |__||__|\n"+
"               |__||__|\n"+
"               |__||__|\n"+
"               /__)/__)\n"+
"              /__//__/\n"+
"             /__//__/\n"+
"            /__//__/.\n"+
"          .'    '.   '.\n"+
"         (________)____)\n";
		
		feat[2]="\n"+
"		           u\n"+                                 
"		           .  x!X\n"+                                 
"		         .\"X M~~>\n"+                                 
"		        d~~XX~~~k    .u.xZ `\\ \\ \"%\n"+                
"		       d~~~M!~~~?..+\"~~~~~?:  \"    h\n"+              
"		      '~~~~~~~~~~~~~~~~~~~~~?      `\n"+              
"		      4~~~~~~~~~~~~~~~~~~~~~~>     '\n"+              
"		      ':~~~~~~~~~~(X+\"\" X~~~~>    xHL\n"+             
"		       %~~~~~(X=\"      'X\"!~~% :RMMMRMRs\n"+          
"		        ^\"*f`          ' (~~~~~MMMMMMMMMMMx\n"+       
"		          f     /`   %   !~~~~~MMMMMMMMMMMMMc\n"+     
"		          F    ?      '  !~~~~~!MMMMMMMMMMMMMM.\n"+   
"		         ' .  :\": \"   :  !X\"\"(~~?MMMMMMMMMMMMMMh\n"+  
"		         'x  .~  ^-+=\"   ? \"f4!*  #MMMMMMMMMMMMMM.\n"+
"		          /\"               ..\"     `MMMMMMMMMMMMMM\n"+
"		          h ..             '         #MMMMMMMMMMMM\n"+
"		          f                '          @MMMMMMMMMMM\n"+
"		        :         .:=\"\"     >       dMMMMMMMMMMMMM\n"+
"		        \"+mm+=~(\"           RR     @MMMMMMMMMMMMM\"\n"+
"		                %          (MMNmHHMMMMMMMMMMMMMMF\n"+ 
"		               uR5         @MMMMMMMMMMMMMMMMMMMF\n"+  
"		             dMRMM>       dMMMMMMMMMMMMMMMMMMMF\n"+   
"		            RM$MMMF=x..=\" RMRM$MMMMMMMMMMMMMMF\n"+    
"		           MMMMMMM       'MMMMMMMMMMMMMMMMMMF\n"+     
"		          dMMRMMMK       'MMMMMMMMMMMMMMMMM\"\n"+      
"		          RMMRMMME       3MMMMMMMMMMMMMMMM\n"+        
"		         @MMMMMMM>       9MMMMMMMMMMMMMMM~\n"+        
"		        'MMMMMMMM>       9MMMMMMMMMMMMMMF\n"+         
"		        tMMMMMMMM        9MMMMMMMMMMMMMM\n"+          
"		        MMMM$MMMM        9MMMMMMMMMMMMMM\n"+          
"		       'MMMMRMMMM        9MMMMMMMMMMMMM9\n"+          
"		       MMMMMMMMMM        9MMMMMMMMMMMMMM\n"+          
"		       RMMM$MMMMM        9MMMMMMMMMMMMMM\n"+          
"		      tMMMMMMMMMM        9MMMMMMMMMMMMMX\n"+          
"		      RMMMMMMMMMM        9MMMMMMMMMMMMME\n"+          
"		     JMMMMMMMMMMM        MMMMMMMMMMMMMME\n"+          
"		     9MMMM$MMMMMM        RMMMMMMMMMMMMME\n"+          
"		     MMMMMRMMMMMX        RMMMMMMMMMMMMMR\n"+          
"		     RMMMMRMMMMME        EMMMMMMMMMMMMM!\n"+          
"		     9MMMMMMMMMME        MMMMMMMMMMMMMM>\n";
		
		
	}
	
	
}
