package client.command;

import command.ICommand;

public class End implements ICommand{

	@Override
	public int numberOfParams() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String execute(String[] params) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean needsRegistration() {
		// TODO Auto-generated method stub
		return false;
	}

	

}
