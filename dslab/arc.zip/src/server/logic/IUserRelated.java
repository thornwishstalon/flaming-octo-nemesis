package server.logic;

public interface IUserRelated {
	public String getUser();
	public void setUser(String user);
	
}
